import { MenuItems } from "./MenuItems";

export interface MenuHeading {
    headingName:string;
    MenuItems:MenuItems[];
}
