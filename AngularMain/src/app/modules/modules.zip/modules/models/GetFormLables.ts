export interface GetFormLabels{
    id:any;
}