export interface EmployeeHistoryDetailsDto {
    employeeId: number;
    contractTypeName: string;
    departmentName: string;
    loadAmount: number;
    installmentDate: Date;
    paid: number;
    pen: any;
}