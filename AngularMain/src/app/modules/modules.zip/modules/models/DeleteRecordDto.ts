export interface DeleteRecordDto{
    employeeId:string;
    username:string
}