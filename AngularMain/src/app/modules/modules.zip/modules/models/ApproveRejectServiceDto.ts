export interface ApproveRejectServiceDto{
    mytransid: number;
    approvalDate: Date;
    rejectionType: number;
    rejectionRemarks: string;
    userid: string;
    entrydate: Date;
    entrytime: Date;
    approvalRemarks: string;
}