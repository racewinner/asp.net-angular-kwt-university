export interface Food{
    name:string;
}