export interface DeleteDataDto{
        id: string;
        locationId: number;
        tenentId: number;
        userId: string;
        username: string;
}