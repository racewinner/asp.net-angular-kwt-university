export interface CountriesDto{
    countryid: number;
    counamE1: string;
    counamE2: string;
}