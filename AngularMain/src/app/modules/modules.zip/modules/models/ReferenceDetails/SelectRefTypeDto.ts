export interface SelectRefTypeDto {    
    refType:string;
}