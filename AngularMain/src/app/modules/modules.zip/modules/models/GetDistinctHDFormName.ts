export interface GetDistinctHDFormName {
    formID: string;
}