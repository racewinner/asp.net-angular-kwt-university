export interface ServiceTypeAndSubTypeIdsDto{
    serviceType: number;
    serviceSubType: number
}