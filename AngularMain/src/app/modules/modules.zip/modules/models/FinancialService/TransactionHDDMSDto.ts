export interface TransactionHDDMSDto {
    tenentId: number;
    mytransid: number;
    serialno: number;
    documentType: number;
    document?: any;
    attachmentPath: string;
    attachmentByName: string;
}






