export interface MenuItems {
    menuItemName:string;
    menuItemURLOption:string;
    menuItems:MenuItems[];

}
