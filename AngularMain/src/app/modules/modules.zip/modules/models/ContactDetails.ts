export interface ContactDetails{
    employeeId:number;
    englishName:string;
}